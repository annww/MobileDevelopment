package vn.duongthianhhong.a64130758_thigiuaky;

public interface OnItemClickListener {
    void onItemClick(User user);
}